# lib_fetcher_image/__init__.py
from .fetcher import FetcherImage